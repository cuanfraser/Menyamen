package org.menyamen.snarl.layout;

import org.junit.jupiter.api.Test;
import org.menyamen.snarl.tiles.Tile;
import org.menyamen.snarl.tiles.Wall;

import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Unit test for Hallway Class.
 */
class HallwayTest {
    /**
     * Rigorous Test.
     */
    @Test
    void testConstructedTiles() {
        // Point start = new Point(0, 0);
        // Point end = new Point(3, 0);

        // Hallway hallway = new Hallway(start, end);

        // List<Tile> expected = new ArrayList<Tile>();
        // expected.add(new Wall(0, -1));
        // expected.add(new OpenTile(0, 0));
        // expected.add(new Wall(0, +1));
        // expected.add(new Wall(1, -1));
        // expected.add(new OpenTile(1, 0));
        // expected.add(new Wall(1, +1));
        // expected.add(new Wall(2, -1));
        // expected.add(new OpenTile(2, 0));
        // expected.add(new Wall(2, +1));
        // expected.add(new Wall(3, -1));
        // expected.add(new OpenTile(3, 0));
        // expected.add(new Wall(3, +1));

        // assertEquals(expected, hallway.constructedTiles());

    }
}
