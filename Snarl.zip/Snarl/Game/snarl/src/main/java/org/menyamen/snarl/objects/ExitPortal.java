package org.menyamen.snarl.objects;

public class ExitPortal implements GameObject {
    
    @Override
    public char toChar() {
        return 'O';
    }
}