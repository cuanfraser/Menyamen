package org.menyamen.snarl.objects;

public class Key implements GameObject {
    @Override
    public char toChar() {
        return 'K';
    }
}