

![alt text](uml.png "UML Diagram")