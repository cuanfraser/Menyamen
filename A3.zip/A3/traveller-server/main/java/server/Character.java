package server;


public class Character {
    public String characterName;
    public String currentTown;

    public Character(String characterName, String currentTown){
        this.characterName = characterName;
        this.currentTown = currentTown;
    }
}