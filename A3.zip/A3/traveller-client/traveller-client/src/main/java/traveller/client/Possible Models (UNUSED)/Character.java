package traveller.client;

public class Character {
    private String name;

    public Character(String name) {
        this.name = name;
    }
}